# Death Runner: build the APK

You need a computer (Windows, Mac or Linux). Android Studio does not run on a phone.

## 1. Install (one time)
- Node.js LTS: https://nodejs.org
- Android Studio: https://developer.android.com/studio (accept the default setup, it installs the Android SDK)

## 2. Prepare the project
1. Unzip this folder and open a terminal inside it (Windows: open the folder, type `cmd` in the address bar, press Enter).
2. Run: `npm install`  (this also downloads three.js so the game works offline)
3. Run: `npx cap add android`
4. Run: `npx cap sync android`

## 3. Add your AdMob App ID
Open `android/app/src/main/AndroidManifest.xml`. Inside the `<application ...>` tag (before `</application>`), add:

    <meta-data
        android:name="com.google.android.gms.ads.APPLICATION_ID"
        android:value="ca-app-pub-4902372831369764~6254768724"/>

Optional, to lock the game to portrait: add `android:screenOrientation="portrait"` to the `<activity ...>` tag.

## 4. Open in Android Studio
Run: `npx cap open android`
Wait until the bottom bar finishes "Gradle sync" (first time can take several minutes).

## 5. Test it
- Phone: enable Developer options and USB debugging, plug it in, pick it at the top, press the green Run button.
- Or create an emulator in Device Manager and press Run.
Ads shown at this stage are Google TEST ads. That is correct.

## 6. Build the APK
Menu: Build, Build Bundle(s) / APK(s), Build APK(s). When it finishes, click "locate" in the popup. The file is `android/app/build/outputs/apk/debug/app-debug.apk`. Send it to your phone and install it (allow "install unknown apps" when asked).

## 7. Final release (Play Store)
1. Open `www/ads-bridge.js` and change `var LIVE=false;` to `var LIVE=true;` (this switches to your real ads).
2. Run `npx cap sync android`.
3. In Android Studio: Build, Generate Signed Bundle / APK. Choose Android App Bundle (AAB) for the Play Store, or APK to share directly.
4. Click "Create new" keystore, fill it in, and SAVE the keystore file and passwords somewhere safe. You need the same keystore for every future update.
5. Choose "release" and finish. The file appears in `android/app/release/`.

## Important
- Never click your own live ads. Keep LIVE=false while testing.
- Your ad IDs are in the game file (`www/index.html`, near the top, `CFG`). Rewarded unit is already set. To add interstitial ads, create an interstitial unit in AdMob and paste its ID into `interstitial:""`.
- App icon: in Android Studio right-click `app/src/main/res`, New, Image Asset.
- After any game change: edit `www/index.html`, run `npx cap sync android`, rebuild.

// Connects the game to AdMob when running inside the Android app.
// LIVE=false uses Google's TEST ads (safe while testing). Set LIVE=true ONLY for the final release build.
(function(){
var LIVE=true;
var TEST={rewarded:"ca-app-pub-3940256099942544/5224354917",inter:"ca-app-pub-3940256099942544/1033173712",rinter:"ca-app-pub-3940256099942544/5354046379"};
var P=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.AdMob;if(!P)return;
setTimeout(function(){var d=document.createElement("div");d.textContent="ADS: "+(LIVE?"LIVE":"TEST");d.style.cssText="position:fixed;bottom:6px;left:6px;z-index:99;font:11px sans-serif;color:#fff;background:#000a;padding:3px 7px;border-radius:8px;pointer-events:none";document.body.appendChild(d);setTimeout(function(){d.remove()},5000)},800);
var ready=P.initialize({initializeForTesting:!LIVE}).catch(function(){});
window.AdMob={
 showRewarded:function(id){return ready.then(function(){return new Promise(function(res,rej){
  var got=false,hs=[];function done(){hs.forEach(function(h){if(h&&h.remove)h.remove()})}
  Promise.all([
   P.addListener("onRewardedVideoAdReward",function(){got=true}),
   P.addListener("onRewardedVideoAdDismissed",function(){done();got?res():rej()}),
   P.addListener("onRewardedVideoAdFailedToLoad",function(){done();rej()}),
   P.addListener("onRewardedVideoAdFailedToShow",function(){done();rej()})
  ]).then(function(a){hs=a;return P.prepareRewardVideoAd({adId:LIVE?id:TEST.rewarded})}).then(function(){return P.showRewardVideoAd()}).catch(function(){done();rej()})})})},
 showInterstitial:function(id){return ready.then(function(){return P.prepareInterstitial({adId:LIVE?id:TEST.inter})}).then(function(){return P.showInterstitial()}).catch(function(){return P.prepareRewardInterstitialAd({adId:LIVE?id:TEST.rinter}).then(function(){return P.showRewardInterstitialAd()})})},
 showRewardedInter:function(id){return ready.then(function(){return new Promise(function(res,rej){
  var got=false,hs=[];function done(){hs.forEach(function(h){if(h&&h.remove)h.remove()})}
  Promise.all([
   P.addListener("onRewardedInterstitialAdReward",function(){got=true}),
   P.addListener("onRewardedInterstitialAdDismissed",function(){done();got?res():rej()}),
   P.addListener("onRewardedInterstitialAdFailedToLoad",function(){done();rej()}),
   P.addListener("onRewardedInterstitialAdFailedToShow",function(){done();rej()})
  ]).then(function(a){hs=a;return P.prepareRewardInterstitialAd({adId:LIVE?id:TEST.rinter})}).then(function(){return P.showRewardInterstitialAd()}).catch(function(){done();rej()})})})}
};
})();

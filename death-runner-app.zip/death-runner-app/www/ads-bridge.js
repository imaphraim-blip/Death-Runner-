// Connects the game to AdMob when running inside the Android app.
// LIVE=false uses Google's TEST ads (safe while testing). Set LIVE=true ONLY for the final release build.
(function(){
var LIVE=false;
var TEST={rewarded:"ca-app-pub-3940256099942544/5224354917",inter:"ca-app-pub-3940256099942544/1033173712"};
var P=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.AdMob;if(!P)return;
var ready=P.initialize({initializeForTesting:!LIVE}).catch(function(){});
window.AdMob={
 showRewarded:function(id){return ready.then(function(){return new Promise(function(res,rej){
  var got=false,hs=[];function done(){hs.forEach(function(h){if(h&&h.remove)h.remove()})}
  Promise.all([
   P.addListener("onRewardedVideoAdReward",function(){got=true}),
   P.addListener("onRewardedVideoAdDismissed",function(){done();got?res():rej()}),
   P.addListener("onRewardedVideoAdFailedToLoad",function(){done();rej()}),
   P.addListener("onRewardedVideoAdFailedToShow",function(){done();rej()})
  ]).then(function(a){hs=a;return P.prepareRewardVideoAd({adId:LIVE?id:TEST.rewarded})}).then(function(){return P.showRewardVideoAd()}).catch(function(){done();rej()})})})},
 showInterstitial:function(id){return ready.then(function(){return P.prepareInterstitial({adId:LIVE?id:TEST.inter})}).then(function(){return P.showInterstitial()})}
};
})();
